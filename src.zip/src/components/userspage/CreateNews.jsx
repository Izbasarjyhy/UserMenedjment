import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NewsService from '../service/NewsService';
import './CreateNews.css';

function CreateNews() {
  const navigate = useNavigate();
  const [newsData, setNewsData] = useState({
    title: '',
    content: '',
    categoryId: ''
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewsData((prevNewsData) => ({
      ...prevNewsData,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await NewsService.createNews(newsData, token);
      setSuccessMessage('News created successfully');
      setErrorMessage('');
      setTimeout(() => {
        navigate("/admin/news-management");
      }, 2000);
    } catch (error) {
      setErrorMessage('Failed to create news');
      setSuccessMessage('');
      console.error('Error creating news:', error);
    }
  };

  return (
    <div className="create-news-container">
      <h2>Create News</h2>
      {successMessage && <p className="success-message">{successMessage}</p>}
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title:</label>
          <input type="text" name="title" value={newsData.title} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label>Content:</label>
          <textarea name="content" value={newsData.content} onChange={handleInputChange} />
        </div>
        <div className="form-group">
          <label>Category ID:</label>
          <select name="categoryId" value={newsData.categoryId} onChange={handleInputChange}>
         <option value="0">Выбирай</option>
         <option value="1">Футбол</option>
         <option value="2">Волейбол</option>
         <option value="3">Баскетбол</option>
         <option value="4">ММА</option>
         <option value="5">Теннис</option>
         <option value="6">Бокс</option>

         </select>
        </div>
        <button type="submit">Create</button>
      </form>
    </div>
  );
}

export default CreateNews;
